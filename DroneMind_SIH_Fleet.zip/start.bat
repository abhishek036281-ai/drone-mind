@echo off
echo Starting DroneMind Backend API Server...
start cmd /k "cd /d %~dp0 && python -m uvicorn backend.main:app --port 8001"

echo Starting DroneMind Frontend Server...
start cmd /k "cd /d %~dp0frontend && python -m http.server 8000"

echo Both servers are starting up! Minimizing this window...
echo Open http://localhost:8000 in your browser.
exit
