const API_BASE = "/api";

const api = {
    async login(email, password) {
        const res = await fetch(`${API_BASE}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });
        if (!res.ok) throw new Error("Invalid email or password");
        return res.json();
    },

    // Admin endpoints
    async getAdminOrganizations() {
        const res = await fetch(`${API_BASE}/admin/organizations`);
        if (!res.ok) throw new Error("Failed to fetch organizations");
        return res.json();
    },
    async getAdminDrones(orgId = "ALL") {
        const res = await fetch(`${API_BASE}/admin/drones?org_id=${orgId}`);
        if (!res.ok) throw new Error("Failed to fetch admin drones");
        return res.json();
    },
    async getAdminMissions(orgId = "ALL") {
        const res = await fetch(`${API_BASE}/admin/missions?org_id=${orgId}`);
        if (!res.ok) throw new Error("Failed to fetch admin missions");
        return res.json();
    },
    async getAdminAnalytics() {
        const res = await fetch(`${API_BASE}/admin/analytics`);
        if (!res.ok) throw new Error("Failed to fetch admin analytics");
        return res.json();
    },
    async getAdminAlerts(orgId = "ALL") {
        const res = await fetch(`${API_BASE}/admin/alerts?org_id=${orgId}`);
        if (!res.ok) throw new Error("Failed to fetch admin alerts");
        return res.json();
    },

    // User/Business endpoints
    async getDrones(orgId = null) {
        const url = orgId ? `${API_BASE}/drones?org_id=${orgId}` : `${API_BASE}/drones`;
        const res = await fetch(url);
        if (!res.ok) throw new Error("Failed to fetch drones");
        return res.json();
    },
    async getMissions(orgId = null) {
        const url = orgId ? `${API_BASE}/missions?org_id=${orgId}` : `${API_BASE}/missions`;
        const res = await fetch(url);
        if (!res.ok) throw new Error("Failed to fetch missions");
        return res.json();
    },
    async runOptimization(orgId = null) {
        const url = orgId ? `${API_BASE}/optimize?org_id=${orgId}` : `${API_BASE}/optimize`;
        const res = await fetch(url, { method: "POST" });
        if (!res.ok) throw new Error("Optimization failed");
        return res.json();
    },
    async simulateFailure(droneId, orgId = null) {
        const url = orgId ? `${API_BASE}/user/simulate/drone-failure?drone_id=${droneId}&org_id=${orgId}` : `${API_BASE}/simulate/drone-failure?drone_id=${droneId}`;
        const res = await fetch(url, { method: "POST" });
        return res.json();
    },
    async simulateEmergency(orgId = null) {
        const url = orgId ? `${API_BASE}/simulate/emergency?org_id=${orgId}` : `${API_BASE}/simulate/emergency`;
        const res = await fetch(url, { method: "POST" });
        return res.json();
    }
};
